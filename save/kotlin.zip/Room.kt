package top.e404.dungeon_generator

data class Room(
    val x: Int,
    val y: Int,
    val w: Int,
    val h: Int
) {
    fun isOverlap(other: Room) = other.x + other.w >= x - 1
            && other.y + other.h >= y - 1
            && x + w >= other.x - 1
            && y + h >= other.y - 1

    fun forEach(block: (x: Int, y: Int) -> Unit) {
        for (iy in y until y + h) for (ix in x until x + w) {
            block(ix, iy)
        }
    }
}