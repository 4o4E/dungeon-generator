package top.e404.dungeon_generator

data class Data<T>(var data: T)