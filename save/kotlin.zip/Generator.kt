package top.e404.dungeon_generator

import java.awt.image.BufferedImage
import kotlin.random.Random

class Generator(
    val dungeonWidth: Int,
    val dungeonHeight: Int,
    val roomWidth: IntRange = 10..25,
    val roomHeight: IntRange = 10..25,
    val roomTry: Int = 200,
    val smooth: Int = 2,
    val fix: Int = 20,
    val fixLimit: Int = 10,
    val loopLimit: Int = 10,
) {
    val rooms = mutableListOf<Room>()
    val arrays = Array(dungeonWidth) { Array(dungeonHeight) { State.WALL } }

    fun <T> round9(x: Int, y: Int, block: (state: State) -> T) = listOf(
        block(arrays[x - 1][y - 1]),
        block(arrays[x][y - 1]),
        block(arrays[x + 1][y - 1]),
        block(arrays[x - 1][y]),
        block(arrays[x][y]),
        block(arrays[x + 1][y]),
        block(arrays[x - 1][y + 1]),
        block(arrays[x][y + 1]),
        block(arrays[x + 1][y + 1]),
    )

    fun <T> round4(x: Int, y: Int, block: (state: State) -> T) = listOf(
        block(arrays[x][y - 1]),
        block(arrays[x - 1][y]),
        block(arrays[x + 1][y]),
        block(arrays[x][y + 1]),
    )

    fun free(x: Int, y: Int) = round9(x, y) { it }.count {
        it == State.WALL
    } > 5

    fun smooth(x: Int, y: Int) = round9(x, y) { it }.count {
        it == State.WALL || it == State.ROOM
    } < 5

    fun newRoom(): Room {
        val w = roomWidth.random()
        val h = roomHeight.random()
        var x: Int
        var y: Int
        do {
            x = Random.nextInt(1, dungeonWidth - w - 1)
            y = Random.nextInt(1, dungeonHeight - h - 1)
        } while (x < 3 && y < 3)
        return Room(x, y, w, h)
    }

    fun genRoom() = repeat(roomTry) {
        val room = newRoom()
        if (rooms.any { it.isOverlap(room) }) return@repeat
        rooms.add(room)
    }

    fun removeDeadEnd(x: Int, y: Int, limit: Data<Int>): Boolean? {
        if (x < 1
            || y < 1
            || x >= dungeonWidth - 1
            || y >= dungeonHeight - 1
        ) return false
        if (round4(x, y) { it }
                .count { it == State.WALL } >= 3
        ) {
            limit.data++
            if (limit.data > fixLimit) return null
            arrays[x][y] = State.WALL
            if (removeDeadEnd(x - 1, y, limit) == null) return null
            if (removeDeadEnd(x + 1, y, limit) == null) return null
            if (removeDeadEnd(x, y - 1, limit) == null) return null
            if (removeDeadEnd(x, y + 1, limit) == null) return null
        } else return false
        return true
    }

    fun removeBox(x: Int, y: Int) {
        if (arrays[x][y] == State.PATH
            && arrays[x + 1][y] == State.PATH
            && arrays[x][y + 1] == State.PATH
            && arrays[x + 1][y + 1] == State.PATH
        ) {
            arrays[x][y] = State.WALL
            arrays[x + 1][y] = State.WALL
            arrays[x][y + 1] = State.WALL
            arrays[x + 1][y + 1] = State.WALL
        }
    }

    private fun loop(x: Int, y: Int, end: Data<Boolean>, limit: Data<Int>, set: MutableSet<Pair<Int, Int>>) {
        if (arrays[x][y] == State.ROOM) {
            end.data = true
            return
        }
        if (end.data || arrays[x][y] != State.PATH) return
        if (set.size > loopLimit) {
            end.data = true
            return
        }
        limit.data++
        if (!set.add(Pair(x, y))) return
        loop(x + 1, y, end, limit, set)
        if (end.data) return
        loop(x - 1, y, end, limit, set)
        if (end.data) return
        loop(x, y + 1, end, limit, set)
        if (end.data) return
        loop(x, y - 1, end, limit, set)
    }

    fun removeLoop(x: Int, y: Int, ignore: MutableList<Pair<Int, Int>>) {
        if (arrays[x][y] != State.PATH
            || Pair(x, y) in ignore
            || x >= dungeonWidth
            || y >= dungeonHeight
        ) return
        val set = hashSetOf<Pair<Int, Int>>()
        val end = Data(false)
        loop(x, y, end, Data(0), set)
        if (end.data) {
            ignore.addAll(set)
            println("end: $set")
            return
        }
        println("rm: $set")
        set.forEach { (x, y) ->
            arrays[x][y] = State.WALL
        }
    }

    fun generator() {
        for (y in 1 until dungeonHeight - 1) {
            for (x in 1 until dungeonWidth - 1) {
                //if (!free(x, y)) continue
                arrays[x][y] = if (Random.nextBoolean()) State.WALL else State.PATH
            }
        }
        repeat(smooth) {
            for (y in 1 until dungeonHeight - 1) for (x in 1 until dungeonWidth - 1) {
                arrays[x][y] = if (smooth(x, y)) State.WALL else State.PATH
            }
        }

        genRoom()
        rooms.forEach { it.forEach { x, y -> arrays[x][y] = State.ROOM } }

        repeat(fix) {
            for (y in 1 until dungeonHeight - 1) for (x in 1 until dungeonWidth - 1) {
                if (round4(x, y) { it }
                        .count { it == State.WALL } >= 3
                ) removeDeadEnd(x, y, Data(0))
            }
        }
        for (y in 1 until dungeonHeight - 1) for (x in 1 until dungeonWidth - 1) {
            removeBox(x, y)
        }
        val ignore = mutableListOf<Pair<Int, Int>>()
        for (y in 1 until dungeonHeight - 1) for (x in 1 until dungeonWidth - 1) {
            removeLoop(x, y, ignore)
        }
        for (y in 1 until dungeonHeight - 1) for (x in 1 until dungeonWidth - 1) {
            if (round4(x, y) { it }
                    .count { it == State.WALL } >= 3
            ) removeDeadEnd(x, y, Data(0))
        }
    }

    fun toImage(): BufferedImage {
        val image = BufferedImage(dungeonWidth, dungeonHeight, BufferedImage.TYPE_INT_RGB)
        for (y in 0 until dungeonHeight) for (x in 0 until dungeonWidth) {
            image.setRGB(x, y, arrays[x][y].color)
        }
        return image
    }
}