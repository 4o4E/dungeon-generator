package top.e404.dungeon_generator

data class Location(var x: Int, var y: Int) {
    operator fun plus(l: Location) = apply {
        x += l.x
        y += l.y
    }

    operator fun minus(l: Location) = apply {
        x -= l.x
        y -= l.y
    }
}
