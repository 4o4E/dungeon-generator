package top.e404.dungeon_generator.pojo

data class Data<T>(var data: T)