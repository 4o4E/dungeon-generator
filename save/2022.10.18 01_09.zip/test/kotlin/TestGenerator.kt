package top.e404.dungeon_generator.test

import org.junit.jupiter.api.Test
import top.e404.dungeon_generator.Dungeon
import java.io.File
import javax.imageio.ImageIO

class TestGenerator {
    @Test
    fun test() {
        val dungeon = Dungeon(
            width = 150,
            height = 150,
            roomWidth = 10..20,
            roomHeight = 10..20,
            roomTry = 500,
            smooth = 2,
            deadEndLimit = 20,
            deadEndStepLimit = 200,
            loopLimit = 200
        )
        dungeon.generator()
        ImageIO.write(dungeon.toImage(), "png", File("out.png"))
    }
}